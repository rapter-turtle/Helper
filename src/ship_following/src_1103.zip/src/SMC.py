import numpy as np
import matplotlib.pyplot as plt

# System parameters
m = 1.0    # Mass (kg)    # Spring constant (N/m)
c = 0.5    # Damping coefficient (Ns/m)

# Control parameter
beta = 0.01  # Sliding mode control parameter
lamda = 3
Kp = 300
Kd = 50

# Initial conditions
initial_position = 0.0
initial_velocity = 0.0

# Desired position
desired_position = 1.0

# Simulation parameters
dt = 0.01       # Time step
total_time = 15  # Total simulation time
real_control = 0.0
filtered_control = 0.0
control_boundary = 9
dead_zone = 10.0

# Lists to store data for plotting
time = []
position = []
control_input = []

# Sliding Mode Control
def sliding_mode_control(x, x_dot, x_desired):
    s = x - x_desired + lamda*x_dot
    control = -Kp*(x - x_desired) - Kd*current_velocity
    control = -1.0 / beta * np.sign(s) - Kp*(x - x_desired) - Kd*current_velocity
    return control

# Simulate the system
current_position = initial_position
current_velocity = initial_velocity

for t in np.arange(0, total_time, dt):
    control = sliding_mode_control(current_position, current_velocity, desired_position)


    if real_control - control > control_boundary:
        real_control = real_control - control_boundary
    elif real_control - control < -control_boundary:
        real_control = real_control + control_boundary
    else:
        real_control = control

    if real_control > -dead_zone and real_control < dead_zone:
        filtered_control = 0.0
    else:
        filtered_control = real_control
        


    # Apply control input to the system (Euler integration)
    acceleration = (filtered_control - c * current_velocity) / m
    current_velocity += acceleration * dt
    current_position += current_velocity * dt

    # Store data for plotting
    time.append(t)
    position.append(current_position)
    control_input.append(real_control)

# Plotting results
plt.figure(figsize=(12, 6))
plt.subplot(2, 1, 1)
plt.plot(time, position, label='Position')
plt.plot(time, [desired_position] * len(time), '--', label='Desired Position')
plt.xlabel('Time (s)')
plt.ylabel('Position')
plt.legend()

plt.subplot(2, 1, 2)
plt.plot(time, control_input, label='Control Input')
plt.xlabel('Time (s)')
plt.ylabel('Control Input')
plt.legend()

plt.tight_layout()
plt.show()